import { create } from 'zustand';
import { persist } from 'zustand/middleware';
// import Logout from '../pages/logout';

let store = (set) => ({
  isLoggedIn: false,
  email: '',
  firstName: '',
  lastName: '',
  accessToken: '',
  setUserState: ({ isLoggedIn, email, firstName, lastName, accessToken }) =>
    set(() => ({ isLoggedIn, email, firstName, lastName, accessToken })),

  logout: () => {
    console.log('logout action called');
    set({ isLoggedIn: false });
  },
});

//persist the state with key "randomKey"
store = persist(store, { name: 'user-supaStore' });

//create the store
let useStore = create(store);

export default useStore;
