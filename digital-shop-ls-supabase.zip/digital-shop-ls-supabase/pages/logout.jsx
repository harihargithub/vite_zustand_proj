// Logout.jsx
import useStore from '../store/supaStore'; // import the Zustand store

const Logout = () => {
  const logout = useStore((state) => state.logout); // get the logout action from the store
  const isLoggedIn = useStore((state) => state.isLoggedIn); // get the isAuthenticated state from the store

  const handleLogout = () => {
    console.log('handleLogout called');
    logout();
    console.log('Logged out');
  };

  return isLoggedIn ? (
    <button onClick={handleLogout}>Confirm Logout</button>
  ) : null;
};

export default Logout;
