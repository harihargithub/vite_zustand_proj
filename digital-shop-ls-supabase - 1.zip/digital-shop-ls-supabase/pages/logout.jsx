// Logout.jsx
import useStore from '../store/supaStore'; // import the Zustand store
import useSupabase from '../hooks/supabase'; // import the supabase hook

const Logout = () => {
  const logout = useStore((state) => state.logout); // get the logout action from the store
  const isLoggedIn = useStore((state) => state.isLoggedIn); // get the isAuthenticated state from the store

  const handleLogout = async () => {
    console.log('handleLogout called');
    await logout();
    console.log('Logged out');

    // Check if the user is logged out
    const user = useSupabase.auth.user;
    if (user === null) {
      console.log('User is logged out');
    } else {
      console.log('User is logged in');
    }
  };

  return isLoggedIn ? (
    <button onClick={handleLogout}>Confirm Logout</button>
  ) : null;
};

export default Logout;
